// Variables to track current selection

let currentPrice = 0;

// Open Modal Function

function openBooking(vehicleName, price) {

    const modal = document.getElementById('bookingModal');

    const vehicleInput = document.getElementById('selectedVehicle');

    const priceInput = document.getElementById('pricePerKm');

    

    // Set values in the form

    vehicleInput.value = vehicleName;

    priceInput.value = '₹' + price;

    currentPrice = price;

    

    // Reset dynamic fields

    document.getElementById('estKm').value = '';

    document.getElementById('totalCost').innerText = '₹0';

    

    // Show modal

    modal.style.display = 'flex';

}

// Close Modal Function

function closeBooking() {

    document.getElementById('bookingModal').style.display = 'none';

}

// Calculate Total Cost dynamically

function calculateTotal() {

    const km = document.getElementById('estKm').value;

    const totalSpan = document.getElementById('totalCost');

    

    if(km && km > 0) {

        const total = km * currentPrice;

        totalSpan.innerText = '₹' + total.toLocaleString(); 

    } else {

        totalSpan.innerText = '₹0';

    }

}

// Handle Form Submission

function handleBooking(event) {

    event.preventDefault(); 

    const name = document.getElementById('userName').value;

    const vehicle = document.getElementById('selectedVehicle').value;

    const km = document.getElementById('estKm').value;

    const total = document.getElementById('totalCost').innerText;

    alert(`Booking Confirmed!\n\nUser: ${name}\nVehicle: ${vehicle}\nEst. Distance: ${km} km\nEst. Cost: ${total}\n\nWe will contact you shortly.`);

    

    closeBooking();

}

// Close modal if user clicks outside the box

window.onclick = function(event) {

    const modal = document.getElementById('bookingModal');

    if (event.target == modal) {

        closeBooking();

    }

}

